## Tutorial Menjalankan BOT Via TERMUX :
      $ pkg install git
      $ pkg install php
      $ git clone https://github.com/arcode13/gojek
      $ cd gojek
      $ php gojek.php
<br/>

## Tutorial Mengecek File .txt Via TERMUX :
      $ pkg install nano
      $ cd gojek
      $ nano token-akun.txt
<br/>

## Tutorial Menghapus Tools TERMUX :
      $ pkg install mc
      $ mc
<br/>

      Thanks To : SGB Team & ArCode
<br/>
